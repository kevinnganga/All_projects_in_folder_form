package Java_BrainsSecurity.Java_BrainsSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBrainsSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
